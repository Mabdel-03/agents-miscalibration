#!/usr/bin/env python3
"""Validate ARD36 counts and output-throughput requirements; does not launch jobs.

Example:
  python budget_check.py --config run_plan.yaml \
    --small-tps-per-replica 220 --large-tps-per-replica 100 \
    --replay-hours 8

Measure effective output throughput over real batches including prefill and both
phases of split-budget generation. Raw decode-only benchmark TPS is not suitable.
This check is necessary, not sufficient: it cannot model the complete DAG or
unmeasured CPU, network, loading, queue, and analysis bottlenecks.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from typing import Any


def load_yaml(path: Path) -> dict[str, Any]:
    try:
        import yaml
    except ImportError as exc:
        raise SystemExit('Install PyYAML to read the provided plan: pip install pyyaml') from exc
    with path.open(encoding='utf-8') as handle:
        result = yaml.safe_load(handle)
    if not isinstance(result, dict):
        raise ValueError('Configuration must contain a mapping.')
    return result


def validate(cfg: dict[str, Any]) -> None:
    c = cfg['cohort']
    if sum(c['natural_splits'].values()) != c['natural_total']:
        raise ValueError('Natural split counts do not sum to the natural total.')
    if sum(c['large_splits'].values()) != c['large_total']:
        raise ValueError('Large-model split counts do not sum to its total.')
    if sum(v['total'] for v in c['families'].values()) != c['natural_total']:
        raise ValueError('Family totals do not match the natural total.')
    for family, fields in c['families'].items():
        if sum(fields[x] for x in ('train','validation','test')) != fields['total']:
            raise ValueError(f'Invalid split in {family}.')
    if cfg['controller']['test_items'] != c['natural_splits']['test']:
        raise ValueError('Controller test count must match the natural test count.')
    if cfg['protocols']['high_budget_native_test_items'] > c['large_splits']['test']:
        raise ValueError('High-budget common subset exceeds shared held-out items.')
    if c['root_draws'] < cfg['protocols']['agents']:
        raise ValueError('Not enough roots for the natural team.')
    if cfg['protocols']['agents'] != 5:
        raise ValueError('This core specification is defined for five agents.')
    if c['challenge_max_items'] > c['natural_splits']['test']:
        raise ValueError('Challenge cap cannot exceed number of test tasks.')
    if cfg['continuation']['small_test_items'] > c['natural_splits']['test']:
        raise ValueError('Small continuation cohort includes non-test items.')
    if cfg['continuation']['large_test_items'] > c['large_splits']['test']:
        raise ValueError('Large continuation cohort includes non-test items.')
    nc = cfg['neural']['capture_splits']
    if sum(nc.values()) != cfg['neural']['capture_total']:
        raise ValueError('Neural split counts do not sum to capture total.')
    for split, count in nc.items():
        if count > c['natural_splits'][split]:
            raise ValueError(f'Neural {split} exceeds natural {split}.')
    if cfg['protocols']['early_stop_on_unanimity']:
        raise ValueError('Early stopping is disallowed in the dynamics experiment.')
    if not cfg['sampler']['seed_in_cache_key']:
        raise ValueError('Independent stochastic seeds must be in cache keys.')
    if cfg['statistics']['natural_and_challenge_cohorts_pooled']:
        raise ValueError('Natural and label-conditioned cohorts must remain separate.')


def ledger(cfg: dict[str, Any]) -> dict[str, dict[str, float]]:
    c, p, s = cfg['cohort'], cfg['protocols'], cfg['sampler']
    n, r = p['agents'], p['update_rounds']
    train_val = c['natural_splits']['train'] + c['natural_splits']['validation']
    cont = cfg['continuation']
    suffix_reserve = (cont['conservative_ledger_items_per_model'] * len(cont['parents'])
                      * cont['suffix_seeds'] * cont['suffix_rounds'] * n)
    assay_per_model = (c['controlled_program_tasks'] * len(cfg['receiver_assay']['presentations'])
                       * len(cfg['receiver_assay']['thinking_tokens'])
                       * c['controlled_program_seeds_per_condition'])
    out: dict[str, dict[str, float]] = {
        'roots': {'small': c['natural_total'] * c['root_draws'], 'large': c['large_total'] * c['root_draws']},
        'natural_dynamics': {'small': c['natural_total'] * len(p['natural_small']) * r * n,
                             'large': c['large_total'] * len(p['natural_large']) * r * n},
        'high_budget_dynamics': {'small': p['high_budget_native_test_items'] * len(p['high_budget_native_protocols']) * r * n,
                                 'large': p['high_budget_native_test_items'] * len(p['high_budget_native_protocols']) * r * n},
        'challenge': {'small': c['challenge_max_items'] * len(c['challenge_initial_correct_counts']) * len(p['challenge']) * r * n,
                      'large': 0},
        'private_counterfactuals': {'small': train_val * len(cfg['controller']['fork_parent_rounds']) * n, 'large': 0},
        'closed_loop_controls': {'small': cfg['controller']['test_items'] * len(cfg['controller']['test_protocols']) * r * n, 'large': 0},
        'selector_diagnostic': {'small': cfg['controller']['selector_diagnostic_calls'], 'large': 0},
        'common_suffix': {'small': suffix_reserve, 'large': suffix_reserve},
        'receiver_assay': {'small': assay_per_model, 'large': assay_per_model},
    }
    low_cap = s['thinking_tokens'] + s['final_tokens']
    assay_cap = sum(cfg['receiver_assay']['thinking_tokens']) / len(cfg['receiver_assay']['thinking_tokens']) + s['final_tokens']
    totals: dict[str, float] = {}
    for model in ('small', 'large'):
        total = sum(v[model] for v in out.values())
        high_count = out['high_budget_dynamics'][model]
        high_cap = p['high_budget_native_thinking_tokens'] + s['final_tokens']
        tokens = (total - assay_per_model - high_count) * low_cap + assay_per_model * assay_cap + high_count * high_cap
        totals[model + '_logical_decisions'] = total
        totals[model + '_generated_token_ceiling'] = int(tokens)
    out['totals'] = totals
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, default=Path(__file__).with_name('run_plan.yaml'))
    parser.add_argument('--hardware', choices=['ten_gpus','twenty_gpus'], default='ten_gpus')
    parser.add_argument('--small-tps-per-replica', type=float)
    parser.add_argument('--large-tps-per-replica', type=float)
    parser.add_argument('--replay-hours', type=float, default=None,
                        help='Measured/projected replay lane duration, including realistic input lengths.')
    parser.add_argument('--json-out', type=Path)
    args = parser.parse_args()
    cfg = load_yaml(args.config)
    validate(cfg)
    result: dict[str, Any] = {'ledger': ledger(cfg), 'includes_optional_modules': False}
    hw = cfg['hardware_starting_plan'][args.hardware]
    window = cfg['hardware_starting_plan']['serving_window_hours']
    reserve = cfg['hardware_starting_plan']['throughput_safety_fraction']
    if not 0 <= reserve < 1:
        raise ValueError('Safety fraction must be in [0,1).')
    totals = result['ledger']['totals']
    for model, measured in [('small', args.small_tps_per_replica), ('large', args.large_tps_per_replica)]:
        count = hw[model + '_replicas']
        tokens = totals[model + '_generated_token_ceiling']
        required = tokens / (count * window * 3600)
        lane: dict[str, Any] = {'replicas': count, 'serving_window_hours': window,
                                'required_effective_tps_without_margin': required,
                                'required_effective_tps_with_margin': required/(1-reserve)}
        if measured is not None:
            if measured <= 0:
                raise ValueError('Measured throughput must be positive.')
            lane['measured_effective_tps'] = measured
            lane['projected_hours_with_margin'] = tokens / (count * measured * (1-reserve) * 3600)
            lane['output_lane_gate_passed'] = lane['projected_hours_with_margin'] <= window
        else:
            lane['output_lane_gate_passed'] = None
        result[model + '_lane'] = lane
    result['replay_hours'] = args.replay_hours
    result['notes'] = [
        'Physical requests may exceed logical decisions under split generation.',
        'Output TPS must include prefill and split-generation overhead.',
        'A passed lane check is not an end-to-end runtime guarantee.',
        'Honor controller-training dependencies and grading/analysis/capture deadlines.',
        'The 32B suffix ledger reserves 64 items, but its held-out analysis has 60.',
    ]
    rendered = json.dumps(result, indent=2)
    print(rendered)
    if args.json_out:
        args.json_out.write_text(rendered + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
