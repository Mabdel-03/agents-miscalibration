# ARD36 handoff bundle

Start with `Agents_Round_Dynamics_36h_Spec.md`. The configuration and helpers support that specification; they are not an implemented multiagent inference runner.

- `run_plan.yaml`: frozen-design starting configuration with unresolved local paths/revisions explicitly set to null.
- `budget_check.py`: executable count/throughput check. Requires Python 3.10+ and PyYAML. Measure throughput on the actual serving stack before using it.
- `conservative_budget.json`: computed default call/token ceilings, without any assertion of actual HPC speed.
- `reference_metrics.py`: standard-library implementations of coverage/count/transition/within-item ranking checks.
- `test_reference_metrics.py`: executable unit tests for those definitions.

Run checks:

```bash
python -m unittest -v test_reference_metrics.py
python budget_check.py --config run_plan.yaml
# Replace the next two rates with measured effective rates, not decode-only TPS.
python budget_check.py --config run_plan.yaml \
  --small-tps-per-replica 220 --large-tps-per-replica 100 --replay-hours 8
```

The example rates in the last command are illustrative inputs, not measured A100/H100 performance. A successful check does not model every dependency, CPU bottleneck, scheduler delay, or grading problem.

The primary delivery is a detailed implementation specification. No experiment has been launched, no HPC runtime has been measured here, and no GPU availability is assumed to have been confirmed.
